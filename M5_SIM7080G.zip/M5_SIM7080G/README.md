# M5 SIM7080G

## Overview

Contains M5Stack **M5 SIM7080G** series related case programs. The hardware is based on the SIM7080G series of modules to realize the NB-IoT/CAT-M communication function.

## Related Link

- [Document & AT Command](https://docs.m5stack.com/en/unit/cat_m)

## License

- [ATOM DTU NB - MIT](LICENSE)

